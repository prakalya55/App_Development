package com.example.Client_Feedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientFeedbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
