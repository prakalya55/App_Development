package com.example.Client_Feedback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientFeedbackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientFeedbackApplication.class, args);
	}

}
